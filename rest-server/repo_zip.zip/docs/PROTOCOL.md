title: Protocol
---

The protocol documentation moved to a separated repo: https://github.com/moleculer-framework/protocol
