"use strict";

require("./suites/" + (process.argv[2] || "common"));
