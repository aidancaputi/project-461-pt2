export default new WeakMap
