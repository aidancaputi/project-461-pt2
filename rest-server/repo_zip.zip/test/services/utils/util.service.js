"use strict";

module.exports = {
	name: "test"
};
