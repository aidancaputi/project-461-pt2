"use strict";

module.exports = {
	name: "my"
};
