module.exports = {
	rules: {
		"no-unused-vars": ["off"]
	}
};
